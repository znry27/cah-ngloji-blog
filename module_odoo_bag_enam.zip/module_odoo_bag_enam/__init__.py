# import berdasarkan nama folder tempat dimana kita menulis file python
# tidak lagi nama file python karena file python sudah tidak di root folder lagi
# file python akan diimport lewat file __init__.py di tiap-tiap folder
import controllers
import models