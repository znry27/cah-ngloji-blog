# -*- coding: utf-8 -*-
from odoo import api, fields, models, exceptions, _
import datetime


class MyServiceDetail(models.Model):    
    _name = 'my.service.detail'
    _description = 'Service Detail'

    # kita sambungkan dengan master product agar tidak perlu ketih nama mesin secara manual
    device = fields.Many2one(string="Nama Mesin",comodel_name="product.product",ondelete="restrict")
    device_sn = fields.Char(string="Serial Number Mesin")

    # kita simpan biaya jasa per produk
    service_price = fields.Float(string="Biaya Jasa")

    # PENTING
    # agar bisa menggunakan One2many kita harus punya relasi Many2one
    service_id = fields.Many2one(string="Form Service",comodel_name="my.service",ondelete="cascade")

# model baru untuk tipe service
class MyServiceType(models.Model):    
    _name = 'my.service.type'
    _description = 'Service Type'

    name = fields.Char(string="Service Type")


class MyService(models.Model):    
    _name = 'my.service'
    _description = 'Service'

    # ubah type_of_service jadi Many2many
    type_of_service = fields.Many2many(
        string="Tipe Service", 
        comodel_name="my.service.type", 
        relation="my_service_my_service_type_rel",
        column1="service_id",
        column2="service_type_id")

    # kode tambahan untuk relasi One2many
    # pastikan pada model terkait sudah dibuat relasi Many2one
    service_detail_ids = fields.One2many(string="Service Detail",comodel_name="my.service.detail", inverse_name="service_id")

    customer = fields.Many2one(string="Nama Pelanggan",comodel_name="res.partner",ondelete="restrict")    
    is_guarantee = fields.Boolean(string="Garansi",default=False)
    description = fields.Text(string="Keluhan Pelanggan")
    service_date = fields.Datetime(string="Tanggal Service",default=fields.Datetime.now)
    scheduled_date = fields.Datetime(string="Perkiraan Selesai",default=fields.Datetime.now)
    finish_date = fields.Datetime(string="Tanggal Selesai")
    take_by_customer_date = fields.Datetime(string="Tanggal Ambil")
    
    state = fields.Selection([
            ('draft','Draft'),
            ('in_progress','In Progress'),
            ('stuck','Stuck'),
            ('cancel','Cancelled'),
            ('finish','Finish'),
            ('take','Take by User')
        ],default='draft')


    @api.multi
    def update_form_to_in_progress(self):
        for record in self:
            record.write({'state':'in_progress'})


    @api.multi
    def update_form_to_cancel(self):
        for record in self:
            record.write({'state':'cancel'})


    @api.multi
    def update_form_to_finish(self):
        for record in self:
            record.write({'state':'finish','finish_date':datetime.datetime.now()})

