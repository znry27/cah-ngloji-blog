# -*- coding: utf-8 -*-
from odoo import api, fields, models, exceptions, _

class MyService(models.Model):    
    _name = 'my.service'

    _description = 'Service'

    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']

    name = fields.Char('Nomor Service', track_visibility='onchange')
    pelanggan = fields.Many2one('res.partner','Pelanggan', track_visibility='onchange')
    tanggal = fields.Date('Tanggal')
    service_detail = fields.One2many('my.service.detail', 'service_id')

    @api.model
    def create(self, values):
        # print values agar kita bisa lihat data apa saja yang terdapat didalamnya
        print(values)

        # check nomor service sudah diisi atau belum jika belum diisi, isi secara manual
        if not values.get('name',False):
            values['name'] = 'NEW'

        # check apakah service detail ada yang garansi atau tidak
        garansi = False
        if values.get('service_detail', []):
            for detail in values.get('service_detail', []):
                if detail[2].get('garansi', False):
                    garansi = True   

        # jika garansi check user yang login saat ini punya group group_prosess_garansi atau tidak
        if garansi and not self.env.user.has_group('tutorial_create_white.group_prosess_garansi'):
            raise exceptions.ValidationError('Anda tidak boleh membuat penerimaan service garansi')

        # jalankan method super dan simpan record yang baru saja dimasukkan kedalam variabel
        # id ini bisa anda gunakan untuk membuat perintah kerja service
        res = super(MyService, self).create(values)

        # siapkan values sebagai data yang akan dimasukkan sebagai Perintah Kerja Service
        perintah_kerja_values = {
            'service_id': res.id, # id dari penerimaan service 
            'teknisi_id': 7, # ini saya hardcode biar simple, dalam aplikasi nyata tentu saja anda harus cari dari database
            'prioritas': 'Urgent' if garansi else 'Normal'
        }

        # buat Perintah Kerja Service dengan data yang sudah dibuat diatas
        # pada kode ini kita masukkan context, agar perintah kerja hanya bisa dibuat dari penerimaan service saja
        self.env['my.service.work.order'].with_context({'create_from_penerimaan_service':1}).create(perintah_kerja_values)

        # jangan lupa return record
        return res

    @api.multi
    def write(self, values):
        # print values agar kita bisa lihat data apa saja yang terdapat didalamnya
        print(values)

        # jalankan method super dulu
        res = super(MyService, self).write(values)

        # kita cek ada detail yang garansi atau tidak
        garansi = False
        for detail in self.service_detail:
            if detail.garansi :
                garansi = True

        # check hak akses garansi
        if garansi and not self.env.user.has_group('tutorial_create_white.group_prosess_garansi'):
            raise exceptions.ValidationError('Anda tidak boleh edit penerimaan service garansi')

        # kita juga perlu update perintah kerja
        # kita cari dulu perintah kerja yang sesuai

        perintah_kerja = self.env['my.service.work.order'].search([('service_id', '=', self.id)])
        if perintah_kerja:
            perintah_kerja.with_context({'write_from_penerimaan_service':1}).write({
                    'prioritas': 'Urgent' if garansi else 'Normal'
                })

        return res



class MyServiceDetail(models.Model):    
    _name = 'my.service.detail'

    _description = 'Service Detail'

    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']

    product = fields.Many2one('product.product', 'Product', track_visibility='onchange')
    keluhan = fields.Char('Keluhan', track_visibility='onchange')
    garansi = fields.Boolean('Garansi')
    service_id = fields.Many2one('my.service')


class ServiceOrder(models.Model):    
    _name = 'my.service.work.order'

    _description = 'Service Order'

    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin']

    name = fields.Char(related='service_id.name')
    service_id = fields.Many2one('my.service', string="Penerimaan Service")
    teknisi_id = fields.Many2one('res.users', string="Teknisi")
    prioritas = fields.Char('Prioritas')

    @api.model
    def create(self, values):
        # disini kita membatasi agar tidak boleh membuat perintah kerja secara manual
        # kita bisa menggunakan context

        # kita check dulu ada context create_from_penerimaan_service atau tidak
        # jika tidak ada kirim pesan ke user

        if 'create_from_penerimaan_service' not in self._context:
            raise exceptions.ValidationError('Anda tidak boleh membuat perintah kerja secara manual')

        # kita jalankan method super
        return super(ServiceOrder, self).create(values)

    @api.multi
    def write(self, values):
        # sama seperti method create disini kita membatasi agar tidak boleh membuat perintah kerja secara manual
       
        # kita check dulu ada context write_from_penerimaan_service atau tidak
        # jika tidak ada kirim pesan ke user

        if 'write_from_penerimaan_service' not in self._context:
            raise exceptions.ValidationError('Anda tidak boleh mengubah perintah kerja secara manual')

        # kita jalankan method super
        return super(ServiceOrder, self).write(values)


    @api.multi
    def unlink(self):
        # kita tidak ingin perintah kerja dihapus, jadi jika anda yang ingin menghapus kita kirim pesan ke user

        raise exceptions.ValidationError('Anda tidak boleh manghapus perintah kerja')