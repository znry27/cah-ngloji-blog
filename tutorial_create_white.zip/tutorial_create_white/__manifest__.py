{
    "name": "Tutorial Create and Write",
    "author": "Cah Ngloji",
    "version": "1.0.0",
    "category": "",
    'website': 'http://www.cahngloji.blogspot.com',
    'summary': '',
    'description': """
            
        """,
    "depends": [
        "product", 
    ],
    "data": [
        "security/security.xml",
        "security/ir.model.access.csv",
        "views/service.xml" 
    ],
    "license": 'LGPL-3', 
    'installable': True 
}
