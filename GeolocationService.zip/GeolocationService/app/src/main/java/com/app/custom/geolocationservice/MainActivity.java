package com.app.custom.geolocationservice;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.Map;
import fi.iki.elonen.NanoHTTPD;

public class MainActivity extends AppCompatActivity {
    private MyServer server;
    private TextView serverStatus;
    private TextView permissionStatus;
    private TextView locationStatus;
    private Button startButton;
    private Button stopButton;
    private Button closeButton;
    private String latLongLocation;
    private LocationManager locationManager;
    private LocationListener locationListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        server = null;
        latLongLocation = "0#0";

        serverStatus = (TextView) findViewById(R.id.server_status);
        permissionStatus = (TextView) findViewById(R.id.permission_status);
        locationStatus = (TextView) findViewById(R.id.location_status);
        startButton = (Button) findViewById(R.id.button_start);
        stopButton = (Button) findViewById(R.id.button_stop);
        closeButton = (Button) findViewById(R.id.button_close);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startServer();
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopServer();
            }
        });

        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new MyLocationListener();


        startServer();

    }

    public void startServer(){
        if(!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
            Toast.makeText(this,"Please Enable your GPS / Location Service.",Toast.LENGTH_LONG).show();
        }else{
            try{
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,10000,2,locationListener);
                if(server == null){
                    server = new MyServer();
                    serverStatus.setText("Service is running");
                }
                permissionStatus.setText("");
            }catch (SecurityException e){
                Log.d("CustomGeolocation",e.getMessage());
                permissionStatus.setText("Permission to access location is disable. Please change from setting menu");
            }catch (IOException e) {
                Log.d("CustomGeolocation",e.getMessage());
                serverStatus.setText("Service is not running");
            }
        }

    }

    public void stopServer(){
        if(server != null) {
            server.stop();
            server = null;
            locationManager.removeUpdates(locationListener);
            serverStatus.setText("Service is not running");
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if(server != null){
            if(server.isAlive()){
                serverStatus.setText("Service is running");
            }else{
                serverStatus.setText("Service is not running");
            }
        }else{
            serverStatus.setText("Service is not running");
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("CustomGeolocation","on destroy");
        stopServer();
    }

    private class MyLocationListener implements LocationListener{
        @Override
        public void onLocationChanged(Location location) {
            String latitudeLongitude = location.getLatitude() + "#" + location.getLongitude();
//            Toast.makeText(getApplicationContext(),"before " + latLongLocation + " after " + latitudeLongitude, Toast.LENGTH_LONG).show();
            latLongLocation = latitudeLongitude;
            locationStatus.setText("Lat: " + location.getLatitude() + " Long: " + location.getLongitude());
        }

        @Override
        public void onStatusChanged(String s, int i, Bundle bundle) {

        }

        @Override
        public void onProviderEnabled(String s) {

        }

        @Override
        public void onProviderDisabled(String s) {

        }
    }

    private class MyServer extends NanoHTTPD {
        private final static int PORT = 3184;

        public MyServer() throws IOException {
            super(PORT);
            start();
            System.out.println( "\nRunning! Point your browers to http://localhost:3184/ \n" );
        }

        @Override
        public Response serve(IHTTPSession session) {
            Response r;
            r = newFixedLengthResponse(latLongLocation);
            r.addHeader("Access-Control-Allow-Origin", "*");

            return r;
        }

//        protected Response addCORSHeaders() {
//            resp.addHeader("Access-Control-Allow-Origin", "*");
//            resp.addHeader("Access-Control-Allow-Headers", calculateAllowHeaders(queryHeaders));
//            resp.addHeader("Access-Control-Allow-Credentials", "true");
//            resp.addHeader("Access-Control-Allow-Methods", ALLOWED_METHODS);
//            resp.addHeader("Access-Control-Max-Age", "" + MAX_AGE);
//
//            return resp;
//        }
    }
}
